var customer = new Array();

var item = new Array();

var orderDb = new Array();

var orderDetails = new Array();
